//logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    imgUrls: [
      'http://img02.tooopen.com/images/20150928/tooopen_sy_143912755726.jpg',
      'http://img06.tooopen.com/images/20160818/tooopen_sy_175866434296.jpg',
      'http://img06.tooopen.com/images/20160818/tooopen_sy_175833047715.jpg'
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 5000,
    duration: 1000,
    iconData:[
      {"type":"1","text":"合作方"},
      { "type": "2", "text": "项目信息" },
      { "type": "3", "text": "合同信息" },
      { "type": "4", "text": "更多" }
    ],
    noticeData: [
      { "title": "公司管理层人员调整", "time": "2018-09-11 12:20:30" },
      { "title": "中秋节公司放假与值班通知", "time": "2018-09-25 12:20:30" },
      { "title": "审批系统规范化操作指导", "time": "2018-09-15 12:20:30" },
      { "title": "审批系统测试结果报告", "time": "2018-08-01 12:20:30" },
      { "title": "公司管理层人员调整", "time": "2018-09-11 12:20:30" },
      { "title": "中秋节公司放假与值班通知", "time": "2018-09-25 12:20:30" }
     
    ],
    navData: [
      { "type": "1", "text": "首页", "url":"" },
      { "type": "2", "text": "待办", "url": "../../pages/havedone/havedone" },
      { "type": "3", "text": "已办", "url": "../../pages/needdone/needdone" },
      { "type": "4", "text": "个人中心", "url": "../../pages/center/center" }
    ]
  },
  changeIndicatorDots: function(e) {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function(e) {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function(e) {
    this.setData({
      interval: e.detail.value
    })
  },
  durationChange: function(e) {
    this.setData({
      duration: e.detail.value
    })
  }
})